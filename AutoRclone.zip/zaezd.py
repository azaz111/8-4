from google.oauth2 import service_account
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import io
from googleapiclient.errors import HttpError
import os , math , time
from sys import argv
import json
import subprocess
from BIB_API import service_avtoriz , perenos_fails_list , spisok_fails_q ,new_drive , \
           spisok_fails_roditelya,createRemoteFolder,peremesti_v_odnu , drive_ls ,_is_success



successful = []

service = service_avtoriz()
service2 = service_avtoriz('v2')

if len(drive_ls(service)) == 1 :
   s_iddrive=drive_ls(service)[0]['id']
else:
   print( 'НЕ пойму какого хрена вижу больше одного диска !  ') 
   s_iddrive=input('Укажи в ручную : ')

n=int(input('С какого диска начинаем :'))
#pap_bibl={}
#for qqq in drive_ls(service):
#    print(qqq)
#    pap_bibl[qqq['name']] = qqq['id']


sp_paps=spisok_fails_q(service,s_iddrive,"mimeType = 'application/vnd.google-apps.folder' and name contains '.d'")
print(' НУжных папок : ' + str(len(sp_paps)))
if len(sp_paps) == 100:
    print('Папок то что нужно')
else:
    print('ВЫ уверены в продолжении папок не хватает')
    input('Да конечно "1" :')
print('Создаю диски')
id_spis=[]
ls_files={}

pap_bibl={}
for qqq in sp_paps:
    print(qqq)
    pap_bibl[qqq['name'][:-4]] = qqq['id'] #Создаем библиотеку папок

n=n-1
while n != len(sp_paps):
    n+=1


    id_nd = new_drive(service,str(n)) 
    file = service.files().get(fileId=pap_bibl[str(n)], supportsAllDrives=True, fields='parents').execute()
    previous_parents = ",".join(file.get('parents'))
    #print(previous_parents)
    #print(f'perenos :{ttt}')
    #print('na rodit'+ str(id_nd) )
    try:
        file = service.files().update(fileId=pap_bibl[str(n)],
                                      addParents=id_nd['id'],
                                      supportsAllDrives=True, 
                                      removeParents=previous_parents, fields='id, parents').execute()
    except HttpError as err: 
        if err.resp.get('content-type', '').startswith('application/json'):
            reason = json.loads(err.content).get('error').get('errors')[0].get('reason')
            print('ОШИБКА : ' + reason)
            print('Ждем дополнительные 10 секунд')
            time.sleep(20) 
            n=n-1

    

    if n==10 or n==20 or n==30 or n==40 or n==50 or n==60 or n==70 or n==80 or n==90:
        input('Я на паузе НАЖМИ ЛЮБУЮ КЛАВИШУ ДЛЯ ПРОДОЛЖЕНИЯ ')
    time.sleep(10) 



