from BIB_API import drive_ls, folder_po_id , service_avtoriz, ls_files_dr_or_fold
import subprocess , time
service = service_avtoriz()
service2 = service_avtoriz('v2')


if len(drive_ls(service)) == 1 :
   mud_id=drive_ls(service)[0]['id']
   mud_name=drive_ls(service)[0]['name']
else:
   print( 'НЕ пойму какого хрена вижу больше одного диска ') 
   exit()

print([eee.get('name') for eee in folder_po_id(service,mud_id,mud_id)])
nnn=input('ВВЕДИ ИМЯ ОСНОВНОЙ ПАПКИ С БЕКАПАМИ : ')

while True:

   while len(drive_ls(service)) != 1 :
      print( 'НЕ могу начать вижу больше одного диска ') 
      time.sleep(30)
   mud_id=drive_ls(service)[0]['id']
   mud_name=drive_ls(service)[0]['name']

   process = subprocess.Popen(['python3', 'copi_bec.py' ,mud_id ,mud_name ,nnn])
   process.wait()
   

   for sps in folder_po_id(service,drive_ls(service)[0]['id']):  ## Нашли клонируемую и копию
      name_vsfold = sps.get('name')
      if name_vsfold == nnn :
         iskoma=sps.get('id')
      if name_vsfold == nnn+'-copy' :
         razn_fold_id = sps.get('id')

   if len(ls_files_dr_or_fold(iskoma,service,)) <= len(ls_files_dr_or_fold(razn_fold_id,service,)):
      print('Выполнено Условие бекап завершен !')
      break
