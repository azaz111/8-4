import os , time
from argparse import ArgumentParser
from subprocess import Popen, PIPE
def mesto(dirs1):
   while True:
      if len(os.listdir(dirs1)) < 1:
         return dirs1
      print('Нет места ......')
      time.sleep(30)

def transfer(dirs,dirs1):
   while True:
      dirfiles = os.listdir(dirs)
      for qqq in  dirfiles:
         if os.stat(dirs+'/'+qqq).st_size > 108650979000:
            if qqq.endswith(".plot"):
               time.sleep(5)
               print('start sortirovki  ' + qqq )
               svdirs=mesto(dirs1)
               print(svdirs)
               comand=f'mv {dirs}/{qqq} {svdirs}'.split()
               print(f'mv {dirs}/{qqq} {svdirs}')
               proc = Popen(comand)
               proc.wait()
      if len(dirfiles) == 0:
         print('нет файлов для сортировки')
         time.sleep(30)
      time.sleep(30)



if __name__ == '__main__':
    parse = ArgumentParser(description=' Настройка трансфера плотов .')
    parse.add_argument('--pach', default='/disk1', help='Путь c плотами .')
    parse.add_argument('--pach1', '-p1', default='/chtemp' , help='Путь к папке 1 .')
    args = parse.parse_args()
    transfer(
       dirs=args.pach,
       dirs1=args.pach1
    )