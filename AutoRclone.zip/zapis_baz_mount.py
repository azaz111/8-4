import os ,time, datetime
try:
    import paramiko
except:
    os.system('pip install paramiko')
    time.sleep(30)
    import paramiko
import conf_bf   
from sys import argv

host = '149.248.8.216'
password='XUVLWMX5TEGDCHDU'
baza='stat_mount.py' # указываем скрипт базы на сервере

def command_toserv(com,host,password):# Отправляем команду в терминал убунту:
    username='root'
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=host, username=username, password=password)  
    result = {}
    for q in com :
        time.sleep(2)
        stdin, stdout, stderr =ssh.exec_command(f'{q}\n')
    output=""    
    try:
        rezul=stdout.read()
        output += rezul
        result[com] = output
    except:
        pass
    print(result)
    ssh.close()
    return rezul

def ipp():
   import socket
   s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
   s.connect(("8.8.8.8", 80))
   return s.getsockname()[0]

def pap_mount():
    osn_serv=conf_bf.osn_serv
    for i in range(10): 
        print(i)
        global data_list
        osn_serv+=1     
        name_osnova='osnova'+str(osn_serv)
        try:
           time.sleep(2)
           sum_plot=len(os.listdir(f'/{name_osnova}/{osn_serv}-1.d'))
           time.sleep(2)
        except:
           sum_plot=0
        if sum_plot >= 1 :
            rezz=(f'Диск_{name_osnova}_смонтирован_✅')
            data_list.append(rezz)
        else:
            rezz=(f'Диск_{name_osnova}_КОСЯЧИТ_🔴')
            data_list.append(rezz)
    return rezz

while True:
    try:
        data_list=[]
         
        data_list.append(ipp()) # добавили айпишку 
        data_list.append(int(time.time()))
        pap_mount()
        print('----------')
        print(data_list)
        print(command_toserv([f'python3 {baza} {data_list[0]} {data_list[1]} {data_list[2]} {data_list[3]} {data_list[4]} {data_list[5]} {data_list[6]} {data_list[7]} {data_list[8]} {data_list[9]} {data_list[10]} {data_list[11]}'],host,password))
        time.sleep(360)
    except:
        print('OSHIBKA vo VREMYA CIKLA')
        time.sleep(200)