import os
from time import sleep
import subprocess
import conf_bf

data_token=input('ВВЕДИ ТОКЕН : ')
old_data=''
old_data_ish=f'[name]\ntype = drive\nscope = drive\ntoken = {data_token}\nteam_drive = data\nroot_folder_id ='
q=0
while q!=100:
   q+=1
   old_data=old_data+'\n\n'+old_data_ish


def moi_drive():# Определяем номер сервера
   sris_drive=[]
   with open("Spisok_drive.txt", "r") as file1:
       for line in file1:
           sris_drive.append(line.strip())
   return sris_drive

#print(moi_drive())
q=0
while q!=100:
   q+=1
   old_data = old_data.replace(f'data', moi_drive()[q-1] ,1 )
   old_data = old_data.replace('name', 'osnova'+str(q) ,1 )

with open('rclone.conf', 'w') as f:
   f.write(old_data)